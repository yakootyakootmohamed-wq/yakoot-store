window.YAKOOT_CONFIG={
  supabaseUrl:'https://bllrjpujvwjvtljajigj.supabase.co',
  supabaseKey:'sb_publishable_2ZPnhU0TA3HXtXWK9juzMw_JK_VwVDt'
};
