// انسخ الملف باسم config.js وضع بيانات مشروع Supabase هنا.
// لا تضع Service Role Key في التطبيق. استخدم Anon/Publishable Key فقط.
window.YAKOOT_CONFIG = {
  SUPABASE_URL: "https://YOUR-PROJECT.supabase.co",
  SUPABASE_ANON_KEY: "YOUR_PUBLIC_ANON_KEY"
};
