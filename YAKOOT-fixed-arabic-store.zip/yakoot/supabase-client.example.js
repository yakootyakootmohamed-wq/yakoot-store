/*
  ملف مثال للربط الفعلي.
  بعد إضافة مكتبة Supabase JS في الاستضافة:
  const client = supabase.createClient(
    window.YAKOOT_CONFIG.SUPABASE_URL,
    window.YAKOOT_CONFIG.SUPABASE_ANON_KEY
  );

  جلب المنتجات:
  const { data, error } = await client
    .from("products")
    .select("*")
    .eq("active", true)
    .order("created_at", { ascending: false });

  إنشاء طلب:
  1) insert في orders
  2) insert في order_items
  3) تفريغ السلة
*/
