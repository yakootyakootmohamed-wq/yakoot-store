(function(){
  if(!window.YAKOOT_CONFIG) throw new Error('YAKOOT_CONFIG missing');
  const s=document.createElement('script');
  s.src='https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2';
  s.onload=function(){ window.supabaseClient=window.supabase.createClient(window.YAKOOT_CONFIG.supabaseUrl,window.YAKOOT_CONFIG.supabaseKey); window.dispatchEvent(new Event('supabase-ready')); };
  document.head.appendChild(s);
})();
