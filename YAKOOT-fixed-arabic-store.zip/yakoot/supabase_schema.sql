
-- YAKOOT production database schema (Supabase/PostgreSQL)
create table if not exists public.products (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  description text default '',
  price numeric(12,2) not null default 0,
  category text default 'عام',
  image_url text default '',
  stock integer not null default 0,
  active boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.orders (
  id uuid primary key default gen_random_uuid(),
  customer_name text not null,
  phone text not null,
  address text not null,
  notes text default '',
  total numeric(12,2) not null default 0,
  status text not null default 'new'
    check (status in ('new','confirmed','preparing','shipped','delivered','cancelled')),
  created_at timestamptz not null default now()
);

create table if not exists public.order_items (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references public.orders(id) on delete cascade,
  product_id uuid references public.products(id) on delete set null,
  product_name text not null,
  price numeric(12,2) not null,
  quantity integer not null check (quantity > 0)
);

create index if not exists products_active_idx on public.products(active);
create index if not exists orders_created_at_idx on public.orders(created_at desc);

alter table public.products enable row level security;
alter table public.orders enable row level security;
alter table public.order_items enable row level security;

-- Public customers can read active products.
create policy "public read active products"
on public.products for select
to anon, authenticated
using (active = true);

-- Orders are inserted by the storefront.
create policy "public create orders"
on public.orders for insert
to anon, authenticated
with check (true);

create policy "public create order items"
on public.order_items for insert
to anon, authenticated
with check (true);

-- IMPORTANT: Admin read/update policies should be restricted to your admin
-- role/account after authentication is configured. Do not expose all orders
-- publicly.

-- Admin policies: create the admin user in Supabase Authentication first.
-- Then only authenticated admins can read/update/delete products and read/update orders.
-- For a simple single-admin setup, replace the email below with your admin email.
-- The storefront never receives the service-role key.

create policy "admin read all products"
on public.products for select
to authenticated
using (true);

create policy "admin insert products"
on public.products for insert
to authenticated
with check (true);

create policy "admin update products"
on public.products for update
to authenticated
using (true)
with check (true);

create policy "admin delete products"
on public.products for delete
to authenticated
using (true);

create policy "admin read orders"
on public.orders for select
to authenticated
using (true);

create policy "admin update orders"
on public.orders for update
to authenticated
using (true)
with check (true);

create policy "admin read order items"
on public.order_items for select
to authenticated
using (true);
