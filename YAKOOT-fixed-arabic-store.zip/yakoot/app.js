let products=[];
let cart=JSON.parse(localStorage.getItem('yakoot_cart')||'[]');
const $=s=>document.querySelector(s);
function money(n){return `${Number(n).toLocaleString('ar-EG')} ج.م`}
function saveCart(){localStorage.setItem('yakoot_cart',JSON.stringify(cart))}
async function loadProducts(){
  const {data,error}=await supabaseClient.from('products').select('*').eq('active',true).order('created_at',{ascending:false});
  if(error){console.error(error); alert('تعذر تحميل المنتجات من قاعدة البيانات. تأكد من تشغيل supabase_schema.sql.'); return;}
  products=(data||[]).map(p=>({id:p.id,name:p.name,price:Number(p.price),cat:p.category,img:(p.image_url&&String(p.image_url).trim())||'assets/256.png'}));
  renderCats(); render();
}
function renderCats(){let cats=[...new Set(products.map(p=>p.cat).filter(Boolean))];$('#category').innerHTML='<option value="">كل الأقسام</option>'+cats.map(c=>`<option>${c}</option>`).join('')}
function render(){let q=$('#search').value.trim().toLowerCase(),c=$('#category').value;let list=products.filter(p=>(!q||p.name.toLowerCase().includes(q))&&(!c||p.cat===c));$('#products').innerHTML=list.map(p=>`<article class="card"><img src="${p.img}" alt="" onerror="this.onerror=null;this.src='assets/256.png'"><div class="card-body"><h3>${p.name}</h3><div class="price">${money(p.price)}</div><button class="add" onclick="add('${p.id}')">أضف للسلة</button></div></article>`).join('')||'<p>لا توجد منتجات.</p>';$('#cartCount').textContent=cart.reduce((a,x)=>a+x.qty,0);renderCart()}
function add(id){let x=cart.find(x=>x.id===id);x?x.qty++:cart.push({id,qty:1});saveCart();render();openCart()}
function renderCart(){let total=0;$('#cartItems').innerHTML=cart.map(x=>{let p=products.find(p=>p.id===x.id);if(!p)return '';total+=p.price*x.qty;return `<div class="cart-row"><img src="${p.img}"><div><b>${p.name}</b><div>${money(p.price)}</div></div><div class="qty"><button onclick="change('${p.id}',-1)">−</button><span>${x.qty}</span><button onclick="change('${p.id}',1)">+</button></div></div>`}).join('')||"<p style='color:#777'>السلة فارغة.</p>";$('#cartTotal').textContent=money(total)}
function change(id,d){let x=cart.find(x=>x.id===id);if(!x)return;x.qty+=d;if(x.qty<=0)cart=cart.filter(x=>x.id!==id);saveCart();render()}
function openCart(){$('#drawer').classList.add('open');$('#overlay').classList.add('show')}
function closeCart(){$('#drawer').classList.remove('open');$('#overlay').classList.remove('show')}
async function checkout(){
 if(!cart.length)return alert('السلة فارغة');
 const name=prompt('اسم العميل:'); if(!name)return;
 const phone=prompt('رقم الهاتف:'); if(!phone)return;
 const address=prompt('العنوان بالتفصيل:'); if(!address)return;
 const notes=prompt('ملاحظات (اختياري):')||'';
 const items=cart.map(x=>{const p=products.find(p=>p.id===x.id);return {product_id:p.id,product_name:p.name,price:p.price,quantity:x.qty}}).filter(Boolean);
 const total=items.reduce((s,x)=>s+x.price*x.quantity,0);
 const {data:order,error}=await supabaseClient.from('orders').insert({customer_name:name,phone,address,notes,total}).select('id').single();
 if(error){console.error(error);return alert('تعذر إنشاء الطلب: '+error.message)}
 const {error:itemError}=await supabaseClient.from('order_items').insert(items.map(x=>({...x,order_id:order.id})));
 if(itemError){console.error(itemError);return alert('تم إنشاء الطلب لكن تعذر حفظ تفاصيله: '+itemError.message)}
 cart=[];saveCart();render();closeCart();alert('تم إرسال الطلب بنجاح ✅\nرقم الطلب: '+order.id);
}
window.add=add;window.change=change;window.openCart=openCart;window.closeCart=closeCart;window.checkout=checkout;
window.addEventListener('supabase-ready',loadProducts);
$('#cartBtn').onclick=openCart;$('#search').oninput=render;$('#category').onchange=render;$('#menuBtn').onclick=()=>location.href='admin.html';document.querySelectorAll('.categories button').forEach(b=>b.onclick=()=>{$('#category').value=b.dataset.cat||'';render();document.getElementById('products').scrollIntoView({behavior:'smooth'})});$('#showAll').onclick=()=>{$('#category').value='';$('#search').value='';render();document.getElementById('products').scrollIntoView({behavior:'smooth'})};
